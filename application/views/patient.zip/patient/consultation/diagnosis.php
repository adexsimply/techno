 <div class="tab-pane" id="diagnosis">
     <h6>Rad Results</h6>

 </div>