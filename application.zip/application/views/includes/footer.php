    
</div>

<!-- Javascript -->
<script src="<?php echo base_url(); ?>assets/bundles/libscripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/bundles/vendorscripts.bundle.js"></script>

<script src="<?php echo base_url(); ?>assets/bundles/chartist.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/bundles/knob.bundle.js"></script> <!-- Jquery Knob-->
<script src="<?php echo base_url(); ?>assets/bundles/flotscripts.bundle.js"></script> <!-- flot charts Plugin Js -->
<script src="<?php echo base_url(); ?>assets/vendor/toastr/toastr.js"></script>
<script src="<?php echo base_url(); ?>assets/vendor/flot-charts/jquery.flot.selection.js"></script>

<!-- Confirm JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

<script src="<?php echo base_url(); ?>assets/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/js/index.js"></script>
<script src="<?php echo base_url(); ?>assets/js/shi.js"></script>
</body>
</html>
