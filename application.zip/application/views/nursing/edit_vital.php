<!-- Add new history Modal -->
<!-- <div class="modal fade" id="takeVitals" tabindex="-1" role="dialog" aria-labelledby="modalUpdatePro" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
        </div>
    </div>
</div> -->



<?php $this->load->view('nursing/new_vital_script'); ?>